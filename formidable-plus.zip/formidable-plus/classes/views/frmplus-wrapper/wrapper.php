<div class="frmplus-wrapper">
	<?php include($view); ?>
</div>